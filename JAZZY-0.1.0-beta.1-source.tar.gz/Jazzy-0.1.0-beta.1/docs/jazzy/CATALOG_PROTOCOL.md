# JAZZY catalog protocol v1

INFO advertises tag `0x5A, 1, 32`: paged factory names, 14-bit factory selection and appended preset high bits. Existing command IDs and parameter v14 encoding are preserved. New start/slot indexes below are **unsigned** 14-bit values (`lo + 128*hi`), unlike the biased signed v14 parameter encoding.

- NAMES (10), extended request: `engine, startLo, startHi, count` (`count <= 32`). Reply: `engine, actualCount`, that many zero-terminated names (up to 12 characters each), the two zero-terminated edit-page titles, then `startLo, startHi, totalLo, totalHi`. The last FMini page starts at 192 and returns eight names; total is 200.
- NAMES legacy request `engine` retains its original response layout and safely returns at most the first 32 entries. Existing small banks remain unchanged. Clients must use the new paging capability to enumerate larger banks.
- PRESET (8), extended request: `engine, slotLo, slotHi`. Reply: `engine, slotLo, slotHi`. The original two-byte request/reply remains compatible for slots 0–127.
- DUMP (4) and TRACK_DUMP (29) append the current preset high byte after their original parameter payloads. RELOAD (24) appends it after `engine, slotLo, selectedTrack`. TRACK (27) appends one high byte per track after its original track tuples. Existing prefixes stay intact.
- FAV_GET/FAV_SET already use biased v14 indexes and now cover every available factory entry, including FMini 199. Settings, crash records and MIDI-learn storage are protected.

USB SysEx frames retain `F0 7D 46 4C command ... F7`. Host regression exercises the actual firmware USB-MIDI framing/queue and checks every FMini page, slot 199 selection/readback, legacy requests and its favorite. Physical USB behavior and third-party clients still require device validation. An older client needs this extension to browse the complete enlarged catalog; no external editor was published by this task.

FMini hardware BANK is 0/1. PATCH is 0–127 for bank 0 and 0–71 for bank 1. Its native program is `BANK*128 + PATCH`. The device descriptor and editor parameter setter enforce the last-bank limit. Shared MIDI PROGRAM CHANGE behavior is retained; use this extended SysEx interface or the hardware browser for the full factory catalog.
