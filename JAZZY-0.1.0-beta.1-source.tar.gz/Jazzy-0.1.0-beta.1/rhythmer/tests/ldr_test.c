/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Host test of the Felucca update loader (firmware/loader/ldr_core.c): a fake
 * host serves a package over the SysEx protocol, the "device" flash starts as
 * another package's flash.bin (as if that firmware were installed).
 *   ldr_test OLD.fwsc NEW.fwsc [APP_SLOT]
 * (0.9.13) with APP_SLOT, the installed app area must declare an app.bin slot of that size, and the encrypted
 * region (app_area_head block + cfg) must end inside [0x4000, 0x93000), the range today's loader writes. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FELUCCA_ID "ota-FM-1_900"
#define FELUCCA_OTA_DRYRUN 0

static uint8_t nor[0x100000], initial_nor[0x100000], *logical;
static uint32_t catalog,catalog_start,embedded,fail_prog=~0u,header_order,header_early,written[2];
static size_t logical_len;
static uint8_t rx[1024];
static uint32_t rx_len, rx_full, now_ms, requests, erases, bad_range, record_cleared, f0_asked;
static uint32_t flip_addr = 0xFFFFFFFFu, flip_seen, flip_on;   /* serve addr's flip_on-th reply with a byte changed */

static uint32_t pack7(const uint8_t *in, uint32_t n, uint8_t *out)
{
    uint32_t acc = 0, nb = 0, o = 0;
    while (n--) {
        acc |= (uint32_t)*in++ << nb;
        nb += 8;
        while (nb >= 7) { out[o++] = acc & 0x7F; acc >>= 7; nb -= 7; }
    }
    if (nb) out[o++] = acc & 0x7F;
    return o;
}
static uint32_t unpack7h(const uint8_t *in, uint32_t n, uint8_t *out)
{
    uint32_t acc = 0, nb = 0, o = 0;
    while (n--) {
        acc |= (uint32_t)*in++ << nb;
        nb += 7;
        if (nb >= 8) { out[o++] = (uint8_t)acc; acc >>= 8; nb -= 8; }
    }
    return o;
}

static int ota_wire_send(const uint8_t *p, uint32_t n)
{
    uint8_t u[64], m[600];
    uint32_t addr, len, i, s = 0;
    unpack7h(p + 1, n - 2, u);
    if (u[2] == 0x11) return 0;
    addr = u[7] | u[8] << 8 | u[9] << 16 | (uint32_t)u[10] << 24;
    len = u[11] | u[12] << 8 | u[13] << 16;
    requests++;
    memcpy(m, "\x00\x59\x30", 3);
    m[3] = (uint8_t)(len + 8); m[4] = (uint8_t)((len + 8) >> 8); m[5] = 0; m[6] = 0;
    memcpy(m + 7, &addr, 4);
    m[11] = (uint8_t)len; m[12] = (uint8_t)(len >> 8); m[13] = 0;
    if (addr >= 0xE0000000u) {
        f0_asked += addr == 0xF0000000u;
        memset(m + 14, 0, len);
        memcpy(m + 14, "success", 8);
    } else {
        if (addr + len > logical_len) { printf("read past the package %#x\n", addr); exit(1); }
        memcpy(m + 14, logical + addr, len);
        if (addr == flip_addr && ++flip_seen == flip_on)
            m[14 + len / 2u] ^= 0x10;                /* a transfer error the frame checksum does not see */
    }
    for (i = 6; i < 14 + len; i++) s += m[i];
    m[14 + len] = (uint8_t)~s;
    rx_len = pack7(m, 15 + len, rx);
    rx_full = 1;
    return 0;
}
static int ota_frame_get(const uint8_t **p, uint32_t *n) { if (!rx_full) return 0; *p = rx; *n = rx_len; return 1; }
static void ota_frame_done(void) { rx_full = 0; }
static uint32_t ota_now_ms(void) { return now_ms; }
static void ota_idle(void) { now_ms++; }
static int ota_erase(uint32_t off) { (void)off; return -1; }
static int ota_prog(uint32_t off, const void *p, uint32_t n) { (void)off; (void)p; (void)n; return -1; }
static int ota_fread(uint32_t off, void *p, uint32_t n) { memcpy(p, nor + off, n); return 0; }
static void ota_show(uint32_t step, int32_t code) { (void)step; (void)code; }
static void ota_commit(const uint8_t *parm) { (void)parm; }
#include "../firmware/src/ota.c"

static int ldr_fread(uint32_t off, void *p, uint32_t n) { memcpy(p, nor + off, n); return 0; }
static int catalog_range(uint32_t off, uint32_t n)
{
    return catalog && ((off >= catalog_start && off + n <= catalog_start + catalog * 0x1000u) ||
                       (off >= 0xDA000u && off + n <= 0xDC000u));
}
static int ldr_erase(uint32_t off)
{
    if (off < 0x4000u || off >= 0xFC000u || (off & 0xFFFu) || (off >= 0x97000u && off < 0xE0000u && !(embedded&&off>=0xA0000u&&off<0xC8000u) && !catalog_range(off, 4096))) bad_range++;
    if (off < 0x4000u) { printf("ERASE IN THE HEAD %#x\n", off); exit(1); }
    erases++;
    memset(nor + off, 0xFF, 0x1000);
    return 0;
}
static int ldr_prog(uint32_t off, const void *p, uint32_t n)
{
    const uint8_t *s = p;
    uint32_t i;
    if (off < 0x4000u || (off + n > 0x93000u && !(embedded&&off>=0xA0000u&&off+n<=0xC8000u) && !catalog_range(off,n)) || ((off & 0xFFu) + n) > 256u) bad_range++;
    if(off==fail_prog){fail_prog=~0u;return -1;}
    if(embedded&&off>=0xA0000u&&off<0xC8000u){
        unsigned slot=(off-0xA0000u)/0x14000u,page=((off-0xA0000u)%0x14000u)>>12;
        if(header_order&&(off&0xFFFu)==0&&page==0&&written[slot]!=0xFFFFEu)header_early++;
        if((off&0xFFFu)==0xF00u)written[slot]|=1u<<page;
    }
    for (i = 0; i < n; i++) nor[off + i] &= s[i];
    return 0;
}
static void ldr_record_clear(void) { record_cleared++; }
static void ldr_progress(uint32_t done, uint32_t total) { (void)done; (void)total; }
#include "../firmware/loader/ldr_core.c"

static uint8_t *load_logical(const char *path, size_t *len)
{
    FILE *f = fopen(path, "rb");
    uint8_t *raw = malloc(0x200000), *lg;
    size_t n, i;
    if (!f) { perror(path); exit(2); }
    n = fread(raw, 1, 0x200000, f);
    fclose(f);
    if (n < 20 * 48 + 0x400) { printf("%s: too short for a package\n", path); exit(2); }
    lg = malloc(n);
    for (i = 0; i < 20; i++) memcpy(lg + i * 47, raw + i * 48, 47);
    memcpy(lg + 20 * 47, raw + 20 * 48, n - 20 * 48);
    *len = n - 20;
    free(raw);
    return lg;
}

static uint32_t flash_off(const uint8_t *lg)        /* flash.bin offset in the logical image */
{
    uint8_t h[0x400];
    uint32_t i, n;
    memcpy(h, lg, sizeof h);
    ota_jl_enc(h, 0x40);
    n = ota_rd16(h + 8);
    for (i = 0; i < n; i++) {
        uint8_t *e = h + 0x40 + i * 0x50u;
        ota_jl_enc(e, 0x50);
        if (ota_rd16(e) == 0) return ota_rd32(e + 8);
    }
    return 0;
}

static int check(const char *what, int ok) { printf("%-56s %s\n", what, ok ? "ok" : "FAIL"); return ok ? 0 : 1; }

/* the installed app area, decrypted with the chip key: app.bin's slot size and CRC, where the region ends */
static int app_area(uint32_t want_slot)
{
    static uint8_t d[0x93000 - 0x4000];
    uint32_t key, blk, app_sz, cfg_sz, end, i;
    int bad = 0;
    if (ldr_chip_key(&key)) return check("chip key from the installed head", 0);
    memcpy(d, nor + 0x4000, sizeof d);
    ldr_sfc(d, sizeof d, 0, key);                   /* (bytes past the region come out as noise: not read) */
    blk = ota_rd32(d + 8);
    app_sz = ota_rd32(d + 32 + 8);
    bad += check("app_area_head and app.bin entries decrypt (CRC16)", ota_crc16(d + 2, 30, 0) == ota_rd16(d) &&
                 ota_crc16(d + 34, 30, 0) == ota_rd16(d + 32) && ota_memeq(d + 32 + 16, (const uint8_t *)"app.bin", 8));
    if (blk >= sizeof d - 32u) return bad + check("app_area_head block inside flash.bin", 0);
    bad += check("app_area_head block CRC16", ota_crc16(d + 32, blk - 32u, 0) == ota_rd16(d + 2));
    bad += check("app.bin CRC16 (the whole slot, as the SPL checks it)",
                 0x120u + app_sz <= blk && ota_crc16(d + 0x120, app_sz, 0) == ota_rd16(d + 32 + 2));
    cfg_sz = ota_rd32(d + blk + 8);
    end = 0x4000u + blk + cfg_sz;
    printf("  app.bin slot %u B (%#x), region [0x4000, %#x), %u B of 0xFF up to 0x93000\n", app_sz, app_sz, end, 0x93000u - end);
    if (want_slot) bad += check("app.bin slot is the packager's APP_SLOT", app_sz == want_slot);
    bad += check("cfg directory entry decrypts", ota_crc16(d + blk + 2, 30, 0) == ota_rd16(d + blk) &&
                 ota_memeq(d + blk + 16, (const uint8_t *)"cfg", 4));
    for (i = end; i < 0x93000u && nor[i] == 0xFF; i++) {}
    bad += check("region ends inside the loader's range, then 0xFF", end <= 0x93000u && i == 0x93000u);
    return bad;
}

int main(int argc, char **argv)
{
    size_t olen;
    static uint8_t user[0x1000], store[0x100000 - 0x93000];
    uint8_t *old, head[0x4000];
    uint32_t ofo, nfo, i;
    int bad = 0, rc;
    if (argc < 3) { printf("usage: ldr_test OLD.fwsc NEW.fwsc [APP_SLOT]\n"); return 2; }
    old = load_logical(argv[1], &olen);
    logical = load_logical(argv[2], &logical_len);
    ofo = flash_off(old);
    nfo = flash_off(logical);
    embedded=logical_len>=nfo+0xC8000u&&ota_memeq(logical+nfo+0x93000u,(const uint8_t *)"RHYBRK1",8);
    catalog = embedded ? ota_rd32(logical+nfo+0x93008u) : 0;
    if (catalog < 2u) catalog = 0;
    catalog_start = catalog == 4 ? 0x93000u : 0x94000u;
    /* device: OLD installed, plus a valid update record at 0xE4F00 (Felucca's step 1) and 0xE8F00 (the stock
     * firmware's, a first install from it); user sample data in Felucca's store that looks like a record */
    memset(nor, 0xFF, sizeof nor);
    for (i = 0x93000u; i < sizeof nor; i++) nor[i] = (uint8_t)(i * 13u ^ i >> 9);   /* store, globals: user data */
    memcpy(nor, old + ofo, 0x93000);
    memcpy(head, nor, sizeof head);
    {
        uint8_t r[112] = {0};
        r[2] = 0x0D; r[3] = 0x5A; r[4] = 0x01; r[5] = 0x5A; r[6] = 0x41; r[7] = 0x54;
        ota_wr16(r, ota_crc16(r + 2, 78, 0));
        memcpy(nor + 0xE4F00, r, sizeof r);
        memcpy(nor + 0xE8F00, r, sizeof r);
        for (i = 0; i < 0x1000u; i++) nor[0xA0000 + i] = (uint8_t)(i * 7u);
        memcpy(nor + 0xA0F00, r, sizeof r);
        memcpy(user, nor + 0xA0000, sizeof user);
        memcpy(store, nor + 0x93000, sizeof store);
        memset(store + (0xE4000 - 0x93000), 0xFF, 0x1000);   /* what the install may change: the two record sectors */
        memset(store + (0xE8000 - 0x93000), 0xFF, 0x1000);
    }
    memcpy(initial_nor,nor,sizeof nor);
    if(argc>3&&!strcmp(argv[3],"reject")){
        rc=ldr_session();bad+=check("invalid integrated package rejected before any erase",rc<0&&!erases&&!memcmp(nor,initial_nor,sizeof nor));return !!bad;
    }
    if(embedded){memcpy(store+(0xA0000-0x93000),logical+nfo+0xA0000,0x28000);header_order=1;}
    if (catalog) {
        memcpy(store + catalog_start - 0x93000u, logical + nfo + catalog_start, catalog * 0x1000u);
        memcpy(store + (0xDA000 - 0x93000), logical + nfo + 0xDA000, 0x2000);
    }
    if (catalog) {
        unsigned record = catalog_start + 0xF00u;
        memcpy(nor + record, nor + 0xE4F00u, 112u);
        rc = ldr_session();
        bad += check("catalog never overwrites an active resume record", rc == -25 && !erases &&
                     !memcmp(nor + record, nor + 0xE4F00u, 112u));
        memcpy(nor + record, initial_nor + record, 112u);
    }
    /* a damaged package (one byte deep in the app area): refused before anything is erased */
    {
        size_t at = nfo + 0x50123u;
        logical[at] ^= 0x01;
        erases = 0;
        rc = ldr_session();
        bad += check("damaged package (flash.bin CRC) refused, nothing erased", rc == -12 && erases == 0 &&
                     !memcmp(nor + 0x4000, old + ofo + 0x4000, 0x93000 - 0x4000) && nor[0xE4F06] == 0x41);
        logical[at] ^= 0x01;
        requests = 0;
    }
    /* a sector that comes in different the second time (a transfer error after the check) is read again */
    flip_addr = nfo + 0x20000u; flip_on = 2; flip_seen = 0;
    rc = ldr_session();
    printf("  rc %d, %u requests, %u sector erases\n", rc, requests, erases);
    bad += check("install completes", rc == 0);
    bad += check("a sector changed in transfer after the check is read again", flip_seen == 3);
    flip_addr = 0xFFFFFFFFu;
    bad += check("app area == the new package's flash.bin", !memcmp(nor + 0x4000, logical + nfo + 0x4000, 0x93000 - 0x4000));
    bad += check("flash head [0, 0x4000) untouched", !memcmp(nor, head, sizeof head));
    bad += check("finish asked (0xF0000000)", f0_asked >= 1);
    bad += check("update records cleared (RAM + flash 0xE4F00, the stock firmware's 0xE8F00)",
                 record_cleared && nor[0xE4F06] == 0xFF && nor[0xE8F06] == 0xFF);
    bad += embedded?check("integrated A/B bytes match exact bundled banks",!memcmp(nor+0xA0000,logical+nfo+0xA0000,0x28000)):check("user data in Felucca's store that looks like a record is kept", !memcmp(nor + 0xA0000, user, sizeof user));
    if(catalog)bad+=check("all catalog sectors match the exact package bytes",
        !memcmp(nor+catalog_start,logical+nfo+catalog_start,catalog*0x1000u)&&!memcmp(nor+0xDA000,logical+nfo+0xDA000,0x2000));
    if(embedded)bad+=check("each bank's header sector is committed after its payload",!header_early);
    header_order=0;
    bad += check("no write outside the allowed windows", bad_range == 0);
    bad += check("projects/settings outside declared banks and records preserved", !memcmp(nor + 0x93000, store, sizeof store));
    bad += app_area(argc > 3 ? (uint32_t)strtoul(argv[3], NULL, 0) : 0u);
    /* same package again: nothing to erase */
    erases = 0; requests = 0;
    rc = ldr_session();
    bad += check("re-run with the same package erases nothing", rc == 0 && erases == 0);
    if(embedded){
        nor[0xA1000]^=1;flip_addr=nfo+0xA1000u;flip_seen=0;flip_on=3;
        rc=ldr_session();bad+=check("changed bank transfer sector is reread, not written corrupt",rc==0&&flip_seen==4&&!memcmp(nor+0xA0000,logical+nfo+0xA0000,0x28000));flip_addr=~0u;
        const unsigned failures[]={0x4100,0xA1100,0xB5100,0xA0100,0xB4100,0x94100,0xDB100,0x96100,0x93100};
        for(unsigned f=0;f<(catalog?5u+catalog:5u);f++){
            memcpy(nor,initial_nor,sizeof nor);nor[failures[f]]^=1;fail_prog=failures[f];record_cleared=f0_asked=erases=0;
            rc=ldr_session();bad+=check("interrupted write keeps resume record and never reports success",rc==-10&&!record_cleared&&!f0_asked);
            rc=ldr_session();bad+=check("resume completes with exact banks and preserved projects/settings",rc==0&&!memcmp(nor+0xA0000,logical+nfo+0xA0000,0x28000)&&!memcmp(nor+0x93000,store,sizeof store)&&!bad_range);
        }
    }
    if(argc>4){FILE *f=fopen(argv[4],"wb");if(!f)return 3;fwrite(nor,1,sizeof nor,f);fclose(f);}
    /* a package for another chip key is refused before any erase */
    {
        uint8_t save = logical[nfo + 0x4000 + 5];
        logical[nfo + 0x4000 + 5] ^= 0x5A;           /* app area head no longer decrypts */
        memcpy(nor, old + ofo, 0x93000);
        erases = 0;
        rc = ldr_session();
        bad += check("foreign key / damaged app head refused, nothing erased", rc == -6 && erases == 0);
        logical[nfo + 0x4000 + 5] = save;
    }
    printf("%s\n", bad ? "LOADER TEST FAILED" : "loader test passed");
    return bad != 0;
}
