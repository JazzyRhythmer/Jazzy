/* Generated reserved-bank tail metadata. No project/song/settings addresses. */
#pragma once
#ifndef JAZZY_EXTERNAL_ASSETS
#define JAZZY_EXTERNAL_ASSETS 0
#endif
#define JAZZY_ASSET_TAIL 73728u
#define JAZZY_ASSET_PAYLOAD 8176u
static const uint32_t JAZZY_ASSET_CRC[2]={801483625u,431358471u};
#if JAZZY_EXTERNAL_ASSETS
static uint8_t jazzy_assets_valid;
static const uint8_t *jazzy_asset_at(unsigned off);
static int jazzy_assets_check(void);
#else
#define jazzy_assets_valid 1
#endif
#define JA_JH_FACTORY 0u
#define JA_JS_CFG 2304u
#define JA_JS_WAVE 2880u
#define JA_JS_DRAW 3008u
#define JA_JS_CHOP 3488u
#define JA_JH_WAVE_PACK 3712u
#define JA_JF_PACK 13868u
