/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
 * Portions Copyright (C) 2026 Juan Ignacio Antonucci (Juan Jiant) */
/* Voice allocation, envelopes, LFO and per-track rendering.
 * Runs in the audio ISR.
 *
 * Each synth part has its own NVOICE voices (so MONO / LEGATO / UNISON keep using
 * v[0..]), but only NVOICE of all the parts' voices sound at once: a part that starts
 * a voice while the budget is full takes one from any part (voice_victim): the oldest
 * released voice, else the oldest extra UNISON voice, else the oldest held voice of a
 * POLY part that is not its lowest note. A voice taken from another part fades out
 * over one block (stage 4: the envelope goes to 0, the block's amplitude ramp
 * declicks it); one of the part's own is restarted in place, as before. Extra UNISON
 * voices only start when there is room. */
static uint32_t vage;                                   /* voice ages: one clock for every part */
/* UI-only note impulse: timestamp is published last, without touching DSP state.
 * Zero is unused; +1 lets a note at millisecond zero animate too. */
static volatile uint32_t six_vis_note_at[NTRK];
static volatile uint8_t six_vis_note_vel[NTRK];
static int32_t lfo_wave(track_t *t, uint32_t ph)
{
    switch (t->p[P_LWAVE]) {
    case 1:
        return osc_tri(ph);
    case 2:
        return (int32_t)(ph >> 16) - 32768;
    case 3:
        return ph < 0x80000000u ? 32767 : -32767;
    case 4:
        return (int32_t)(t->lfo_rnd >> 16) - 32768;
    default:
        return osc_sine(ph);
    }
}

/* the S&H value of a new LFO cycle. Parts 1..3 draw it from the shared generator (rng); part 4 has its
 * own xorshift, so the shared sequence, which also seeds the engines' noise (PHYS, VOICE, ..), does not
 * depend on part 4's LFO (the golden renders rely on it) */
#define LFO_SHARED_RNG 3u
static uint32_t lfo_rand(track_t *t)
{
    uint32_t s = t->lfo_rnd ? t->lfo_rnd : 0x9E3779B9u;
    if ((uint32_t)(t - trk) < LFO_SHARED_RNG)
        return rng();
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    return s;
}

/* (JIANT 0.5) ANALOG's FILTER TYPE COMB: the part's sum through a feedback comb, tuned to its newest note moved by
 * CUT (+-32 semitones; 64: the note: a resonance at the pitch), RES its feedback (up to ~0.99: long metallic rings);
 * the level kept about the dry's. One line a part (1024 samples: down to ~43 Hz) */
#define COMB_LEN 1024u
static int16_t comb_buf[NTRK][COMB_LEN] __attribute__((section(".pool")));   /* (0.6: six tracks, in the pool) */
static uint16_t comb_w[NTRK];
static int16_t comb_p16[NTRK];
static __attribute__((noinline)) void track_comb(track_t *t, int32_t *out, uint32_t n, int32_t cut, int32_t res)
{
    uint32_t ti = (uint32_t)(t - trk) % NTRK, i, per, age = 0, w = comb_w[ti];
    int32_t p16 = comb_p16[ti], fb = 16000 + res * 130, g = 32768 - fb;
    int16_t *b = comb_buf[ti];
    for (i = 0; i < NVOICE; i++)                        /* the newest note sounding */
        if (t->v[i].active && t->v[i].age >= age) {
            age = t->v[i].age;
            p16 = t->v[i].pitch_cur;
        }
    comb_p16[ti] = (int16_t)p16;
    p16 = clamp(p16 + (cut - 64) * 8, 0, 2047);
    per = 0xFFFFFFFFu / ((pitch_inc((uint32_t)p16) >> 8) | 1u);   /* the period, Q8 */
    per = per < (2u << 8) ? 2u << 8 : per > ((COMB_LEN - 2u) << 8) ? (COMB_LEN - 2u) << 8 : per;
    for (i = 0; i < n; i++) {
        uint32_t d = per >> 8;
        int32_t a = b[(w - d) & (COMB_LEN - 1u)], c = b[(w - d - 1u) & (COMB_LEN - 1u)];
        int32_t x = (a + (((c - a) * (int32_t)(per & 255u)) >> 8)) << 1, y = out[i] + mulq15(x, fb);
        b[w & (COMB_LEN - 1u)] = (int16_t)clamp(y >> 1, -32768, 32767);
        w++;
        y = clamp(y, -262000, 262000);                  /* (0.6.81: y * g overflowed with a loud part, ~96000 in: the
                                                         * sign flipped, a full-scale crackle; a quarter first) */
        out[i] = soft_knee((((y >> 2) * g) >> 15) * 8 + (out[i] >> 2), 24000);
    }
    comb_w[ti] = (uint16_t)w;
}

/* (JIANT 0.5) the FILTER of every engine but ANALOG (its own, per voice): the part's sum through a drive (DRV: x1 ..
 * x4 into the soft clip, the level kept) and a state-variable filter, LP HP BP at CUT (moved by the LFO and the loudest
 * voice's envelope through LFO DEST / ENV DEST FLT) and RES; COMB the comb above (CUT about the newest note, RES its
 * feedback). LP open (127), no drive: out of the chain.
 * (JIANT 0.6.8, the crackles turning CUT / RES) going in and out of the chain, and from one TYPE to another, crossfade
 * over the block, the state taken from the input on the way in (it was stale: a step each time CUT or RES crossed the
 * open LP) */
static int32_t tf_ic1[NTRK], tf_ic2[NTRK];

/* (0.6.81) a DRUM part's IMAGE: what each side gives up (eng_drum.c dx_sl dx_sr) filtered as the part is, or the side
 * taken out of the filtered sum was unfiltered: its highs back in raw, a grit like a bitcrusher. The same filter, linear,
 * in and out with the part's fades */

static uint8_t tf_on[NTRK], tf_ft[NTRK];        /* the SVF in the chain the last block; the TYPE playing (0.6.71: a
                                                 * byte a track, not a bit: two cores write two tracks at once) */
static uint8_t tf_cmb[NTRK];                    /* (0.6.81) the COMB ran the last block (its line live) */
static uint8_t tf_xb[NTRK], tf_fo[NTRK];        /* (0.6.81) a TYPE's crossfade: its blocks left, the TYPE from (TF_DRY:
                                                 * no filter) */
#define TF_XB 8u                                /* (~5 ms: one block's fade between two filters was a tick) */
#define TF_DRY 0xFFu
/* the filter of TYPE ft on a part's block; fo (not TF_DRY, an SVF TYPE): from fo's output to ft's, w0 + (i + 1) dw
 * (Q12) of the way (the SVF's three outputs from one state); own: the engine filters its notes itself (ANALOG, LOFI):
 * only the COMB here, at cut / res */
static __attribute__((noinline)) void tf_run(track_t *t, int32_t *out, uint32_t n, uint32_t ft, uint32_t fo, int32_t w0,
                                             int32_t dw, uint32_t own, int32_t ccut, int32_t cres)
{
    const int16_t *p = t->p;
    uint32_t ti = (uint32_t)(t - trk) % NTRK, i;
    int32_t cut = p[P_FCUT] << 8, envq = 0, ic1 = tf_ic1[ti], ic2 = tf_ic2[ti], k;
    tsvf_t c;
    if (ft == FT_COMB) {
        if(t->engine==ENGI_BREAK){
            int32_t lfo=mulq15(t->lfo_val,t->lfo_fade);
            ccut=clamp(ccut+((((lfo*p[P_LD_FLT])>>7)+((t->m_env*p[P_ED_FLT])>>7)+t->v[0].s[BENV_CUT])>>8),0,127);
            comb_p16[ti]=60*16;
        }
        if (!tf_cmb[ti])                                /* (0.6.81) in: its line cleared (the last time's, stale) */
            memset(comb_buf[ti], 0, sizeof comb_buf[ti]);
        track_comb(t, out, n, ccut, cres);
        tf_cmb[ti] = 1;
        return;
    }
    if (own)
        return;
    if(t->engine==ENGI_BREAK)envq=t->m_env;
    for (i = 0; i < NVOICE; i++)
        if (t->v[i].active && t->v[i].stage && t->v[i].stage < 4u && (t->v[i].env >> 9) > envq)
            envq = t->v[i].env >> 9;
    {   /* (0.6.81) the sweep kept where it is heard: CUT moved down so its top stays open at most (an open filter swept
         * up did nothing: half an LFO's cycle, a whole ENV, lost) */
        int32_t d2=lfo2_dest_value(t,1);
        int32_t span = ((p[P_LD_FLT] < 0 ? -p[P_LD_FLT] : p[P_LD_FLT])+(d2<0?-d2:d2)) * 256 + (p[P_ED_FLT] > 0 ? p[P_ED_FLT] * 256 : 0);
        if (cut + span > (127 << 8))
            cut = (127 << 8) - span > 0 ? (127 << 8) - span : 0;
    }
    cut += ((mulq15(t->lfo_val, t->lfo_fade) * p[P_LD_FLT]) >> 7) + ((envq * p[P_ED_FLT]) >> 7);
    if(t->engine!=ENGI_BREAK)cut+=(mulq15(t->lfo2_val,t->lfo2_fade)*lfo2_dest_value(t,1))>>7;
    if(t->engine==ENGI_BREAK)cut+=t->v[0].s[BENV_CUT];
    {
        uint32_t on = !(ft == FT_LP && fo == TF_DRY && cut >= (127 << 8) && !p[P_FRES]), was = tf_on[ti];
        if (!on && !was)
            return;                                     /* (open: nothing to filter) */
        if (!was) {                                     /* in: the state as the input (no step) */
            ic1 = 0;
            ic2 = out[0];
        }
        tsvf_coef(&c, cut, p[P_FRES]);
        k = 8192 - p[P_FRES] * 7600 / 127;
        for (i = 0; i < n; i++) {
            int32_t x = out[i], y, w = (int32_t)((i + 1u) << (12 - CTL_LOG2));   /* 0 .. 1 over the block, Q12 */
            int32_t v3 = x - ic2, v1 = (c.a1 * ic1 + c.a2 * v3) >> 13, v2 = ic2 + ((c.a2 * ic1 + c.a3 * v3) >> 13);
            ic1 = clamp(2 * v1 - ic1, -150000, 150000);
            ic2 = clamp(2 * v2 - ic2, -150000, 150000);
            y = ft == FT_HP ? x - v2 - ((k * v1) >> 12) : ft == FT_BP ? (k * v1) >> 12 : v2;
            if (fo != TF_DRY) {                         /* TYPE changed: from the old one's output */
                int32_t y0 = fo == FT_HP ? x - v2 - ((k * v1) >> 12) : fo == FT_BP ? (k * v1) >> 12 : v2;
                y = y0 + (((y - y0) * (w0 + (int32_t)(i + 1u) * dw)) >> 12);
            }
            y = soft_knee(y, 30000);                    /* (the dry part has no knee: the fades after it) */
            if (!was)
                y = x + (((y - x) * w) >> 12);          /* in */
            else if (!on)
                y = y + (((x - y) * w) >> 12);          /* out */
            out[i] = y;
        }

        tf_on[ti] = (uint8_t)on;
    }
    tf_ic1[ti] = ic1;
    tf_ic2[ti] = ic2;
}

/* the FILTER after the voices. (0.6.81) A TYPE turned crossfades over TF_XB blocks from the one playing (the TYPE held
 * until it is done): between LP HP BP inside the SVF; into or out of the COMB (or into it from no filter) both run, the
 * old on a copy (was: one block, and the COMB left out: a step each way) */
static int32_t tf_tmp_core[2][CTL]; /* each render core owns its transition scratch */
static __attribute__((noinline)) void track_filter(track_t *t, int32_t *out, uint32_t n, uint32_t own, int32_t ccut,
                                                   int32_t cres)
{
    uint32_t ti = (uint32_t)(t - trk) % NTRK, r = (uint32_t)t->p[P_FTYPE] & 3u, ft, fo, i;
    int32_t *tf_tmp=tf_tmp_core[MC_CPU()&1u];
    uint32_t act = (tf_on[ti] && !own) || tf_cmb[ti];
    int32_t w0, dw;
    if (own && r != FT_COMB)
        r = FT_LP;                                      /* (an engine's own filter: COMB or nothing here) */
    if (!tf_xb[ti]) {
        if (r != tf_ft[ti] && (act || r == FT_COMB)) {
            tf_fo[ti] = (uint8_t)(act ? tf_ft[ti] : TF_DRY);
            tf_xb[ti] = TF_XB;
        }
        tf_ft[ti] = (uint8_t)r;
    }
    ft = tf_ft[ti];
    if (!tf_xb[ti]) {
        tf_run(t, out, n, ft, TF_DRY, 0, 0, own, ccut, cres);
        tf_cmb[ti] = ft == FT_COMB;
        return;
    }
    if (n > CTL)
        n = CTL;
    fo = tf_fo[ti];
    w0 = (int32_t)(((TF_XB - tf_xb[ti]) << 12) / TF_XB);
    dw = (4096 / (int32_t)TF_XB) >> CTL_LOG2;
    if (fo != TF_DRY && fo != FT_COMB && ft != FT_COMB && !own) {
        tf_run(t, out, n, ft, fo, w0, dw, own, ccut, cres);   /* (one SVF, two of its outputs) */
    } else {
        for (i = 0; i < n; i++)
            tf_tmp[i] = out[i];
        if (fo != TF_DRY)
            tf_run(t, tf_tmp, n, fo, TF_DRY, 0, 0, own, ccut, cres);   /* the old one */
        tf_run(t, out, n, ft, TF_DRY, 0, 0, own, ccut, cres);
        for (i = 0; i < n; i++)
            out[i] = tf_tmp[i] + (((out[i] - tf_tmp[i]) * (w0 + (int32_t)(i + 1u) * dw)) >> 12);
    }
    if (!--tf_xb[ti])
        tf_cmb[ti] = ft == FT_COMB;
}

/* the FILTER after the voices: ANALOG's and LOFI's COMB here (their own filters are per voice), every other engine's
 * whole filter (track_filter). Its own function: the audio ISR's loop stays as it was */
static __attribute__((noinline)) void track_post(track_t *t, const engine_t *e, int32_t *out, uint32_t n)
{
    if (e == &ENG_ANALOG)
        track_filter(t, out, n, 1, t->p[P_E4], t->p[P_E5]);
    else
        track_filter(t, out, n, e == &ENG_LOFI, t->p[P_FCUT], t->p[P_FRES]);
}

static uint32_t beat_samples(void);                     /* (fx.c) */
static void track_lfo_tick(track_t *t)
{
    uint32_t old = t->lfo_ph;
    int32_t r = t->p[P_LRATE];
    if (r < 0) {                                        /* (JIANT 0.6.51) in time: 4BAR .. 1/32 (params.c N_LSYNC), on
                                                         * the transport's grid while it plays (PHASE its offset), free
                                                         * while it is stopped */
        static const uint16_t U[12] = {384, 192, 96, 48, 24, 18, 16, 12, 8, 6, 4, 3};   /* 1/24 of a quarter */
        uint32_t len = beat_samples() * U[(uint32_t)(-r - 1) % 12u] / 24u;
        if (len < 64u)
            len = 64u;
        if (song.playing)
            t->lfo_ph = (uint32_t)(((uint64_t)(ms_clock % len) << 32) / len) +
                        (t->p[P_LPHASE] > 0 ? (uint32_t)t->p[P_LPHASE] << 25 : 0u);
        else
            t->lfo_ph += (uint32_t)(((uint64_t)CTL << 32) / len);
    } else
        t->lfo_ph += LFO_INC[r & 127];
    if (t->lfo_ph < old)
        t->lfo_rnd = lfo_rand(t);
    t->lfo_val = lfo_wave(t, t->lfo_ph);
    if (t->lfo_fade < 32767) {
        int32_t step = (int32_t)(ENV_LIN[t->p[P_LFADE] & 127] >> 9);
        t->lfo_fade = t->p[P_LFADE] ? clamp(t->lfo_fade + (step ? step : 1), 0, 32767) : 32767;
    }
}

static int32_t six_lfo2_wave(const track_t *t,uint32_t ph){
 switch(t->p[P_L2WAVE]){case 1:return osc_tri(ph);case 2:return (int32_t)(ph>>16)-32768;
 case 3:return ph<0x80000000u?32767:-32767;case 4:return (int32_t)(t->lfo2_rnd>>16)-32768;
 default:return osc_sine(ph);}
}
static void six_lfo2_tick(track_t *t){
 uint32_t old=t->lfo2_ph;int r=t->p[P_L2RATE];
 if(r<0){static const uint16_t u[12]={384,192,96,48,24,18,16,12,8,6,4,3};
  uint32_t len=beat_samples()*u[(unsigned)(-r-1)%12u]/24u;if(len<64)len=64;
  if(song.playing)t->lfo2_ph=(uint32_t)(((uint64_t)(ms_clock%len)<<32)/len)+(t->p[P_L2PHASE]>0?(uint32_t)t->p[P_L2PHASE]<<25:0u);
  else t->lfo2_ph+=(uint32_t)(((uint64_t)CTL<<32)/len);
 }else t->lfo2_ph+=LFO_INC[r&127];
 if(t->lfo2_ph<old){uint32_t r=t->lfo2_rnd?t->lfo2_rnd:0x6D2B79F5u+(unsigned)(t-trk)*7919u;r^=r<<13;r^=r>>17;r^=r<<5;t->lfo2_rnd=r;}
 t->lfo2_val=six_lfo2_wave(t,t->lfo2_ph);
 if(t->lfo2_fade<32767){int step=(int)(ENV_LIN[t->p[P_L2FADE]&127]>>9);
  t->lfo2_fade=t->p[P_L2FADE]?clamp(t->lfo2_fade+(step?step:1),0,32767):32767;}
}

/* (0.9.18) the LFOs' FADE from 0 again: a project loaded (project.c project_restore_runtime), the power-on (lfo_fade 0
 * already), a track's MODE turned to FREE (ui_input.c knob_turn: the one track). MODE TRIG fades on each fresh phrase
 * anyway (trk_note_on); FREE only then */
static void lfo_fade_restart(uint32_t mask)
{
    uint32_t k;
    for (k = 0; k < NTRK; k++)
        if ((mask >> k) & 1u)
            trk[k].lfo_fade = trk[k].lfo2_fade = 0;
}

/* voices the engine may use (POLY and UNISON): its cap, else all of them */
/* (JIANT 0.6.29, 0.6.30) GLO > SYSTEM > LOAD (MENU > SYSTEM > LOAD): how much of the CPU the heavy parts may take,
 * swapped while they sound, the project keeping its settings (ui.c ui_load, rp_apply). FULL: all as set. LITE: their
 * light kin: FM6 two voices, the reverb SHIMMER / CLOUD as ROOM, RESO as SPRING, the GRAIN delay plain (fx.c). ECO:
 * LITE, and every reverb a SPRING (0.6.70: its chain shortened, fx.c SP_N_ECO), no chorus, no SLICER (slicer.c: its
 * tracks straight to the mix, its pages hidden), at most ECO_POLY voices a track (an engine of hits, DRUM, as ever),
 * ECO_VOICES between all (voice_cap), the load budget sooner (audio.c TIGHT_ON_ECO) */
enum { LOAD_FULL, LOAD_LITE, LOAD_ECO };
static volatile uint8_t sys_load;
/* (0.9.13) the load governor (audio.c gov_tick), ahead of the overload guard: gov_cap the voices all parts may share
 * (one less after 6 halves in a row over the load budget, one more after 0.5 s under it, 4 at least), gov_lite LOAD LITE
 * of its own while the guard keeps fading voices (two sheds in a second; 5 s calm to go back): the song's polyphony and
 * the heavy reverbs give way before the audio is late. LOAD_EFF(): the LOAD the sound plays (the MENU's, else the
 * governor's) */
static volatile uint8_t gov_cap = 16u, gov_lite;
#define LOAD_EFF() (sys_load ? sys_load : gov_lite)
#define LITE_FM6_POLY 2u
#define ECO_POLY 4u
#define ECO_VOICES 6u            /* (0.6.70) LOAD ECO: the voices all parts share (NVOICE else) */
static uint32_t trk_nvoice(const track_t *t)
{
    uint32_t c = ENGINES[t->engine]->poly;
    if (LOAD_EFF() && t->engine == ENGI_FM6 && c > LITE_FM6_POLY)
        c = LITE_FM6_POLY;
    if (sys_load == LOAD_ECO && !ENGINES[t->engine]->oneshot && (!c || c > ECO_POLY))
        c = ECO_POLY;
    return c && c < NVOICE ? c : NVOICE;
}

/* the part's voice mode: P_VOICE, POLY for an engine of hits (engine_t.oneshot: DRUM) */
static uint32_t trk_vmode(const track_t *t)
{
    return ENGINES[t->engine]->oneshot ? V_POLY : (uint32_t)t->p[P_VOICE];
}

/* ------------------------------------------------- the shared voice budget --- */
/* (JIANT 0.6.16) the load budget: audio.c sets it when a half took more than 65 % of its time (the render), clears
 * it after a while under 60 %. While it is set the sound may not grow: a new note takes a voice (the oldest released
 * first) instead of adding one (voice_room), CLOUD spawns half its grains (fx.c). Ahead of the overload guard (80 %:
 * a voice faded) and of a late half (a click): the load stops climbing before it gets there */
static volatile uint8_t load_tight;
/* (0.6.17) what the audio did since power-on, for MENU > ABOUT (audio.c fills it): the slowest half's share of its
 * time (%), the halves that came late (each a click), the voices the overload guard faded */
static struct { volatile uint32_t peak, late, shed; } load_diag;
/* (JIANT 0.6.70) the budget shared by all parts: NVOICE, LOAD ECO ECO_VOICES (4 parts with reverb and delay still
 * crackled on ECO: the peaks are the voices, a tail ringing on each part as the next hits come). (0.9.12, after Skiff
 * by illuminus5) VOICES_2CORE while the second core takes parts (fx.c mc_two: CORES 2, not REC at power-on, not given
 * up): the room its render gives. A part still has NVOICE of its own (track_t.v: no RAM more); the load budget
 * (load_tight) and the overload guard (audio.c) measure core 0's half with core 1's wait in it, so they hold the
 * render in its time either way; a core 1 given up mid-session: NVOICE again from the next note */
#define VOICES_2CORE 12u
static int mc_two(void);                                /* (fx.c) */
static int six_track_enabled(unsigned k);
static uint32_t voice_budget(void)
{
    return sys_load == LOAD_ECO ? ECO_VOICES : mc_two() ? VOICES_2CORE : NVOICE;
}
static uint32_t voice_cap(void)
{
    uint32_t c = voice_budget();
    return c < gov_cap ? c : gov_cap;
}
static uint32_t voices_busy(void)                       /* sounding voices of all parts (not the fading ones) */
{
    uint32_t p, i, n = 0;
    for (p = 0; p < NPART; p++)
        for (i = 0; i < NVOICE; i++)
            n += trk[p].v[i].active && trk[p].v[i].stage != 4u;
    return n;
}

static uint32_t lowest_held(const track_t *t)           /* index of the lowest held note (the bass), NVOICE = none */
{
    uint32_t i, low = NVOICE;
    for (i = 0; i < NVOICE; i++)
        if (t->v[i].active && t->v[i].gate && (low == NVOICE || t->v[i].note < t->v[low].note))
            low = i;
    return low;
}

/* Protect the transient, not the entire drum lifetime. kfade is unused until
 * stage 4 and is reset on each hit (including FLAM); it counts rendered CTLs.
 * Past 40 ms a drum tail participates in the original budget/overload policy. */
#define DRUM_ATTACK_BLOCKS ((FS * 40u + CTL * 1000u - 1u) / (CTL * 1000u))


/* the voice to give up for a new one (see the top); soft: only released voices and
 * extra voices of other non-POLY parts (also ones left after a mode change).
 * Returns its index, *pp its part; NVOICE = none */
static uint32_t voice_victim(const track_t *self, int soft, track_t **pp)
{
    uint32_t p, i, best = NVOICE, cat = 4;
    for (p = 0; p < NPART; p++) {
        track_t *t = &trk[p];
        uint32_t mode = trk_vmode(t);
        uint32_t low = mode == V_POLY ? lowest_held(t) : NVOICE;
        if (soft && t == self)
            continue;
        for (i = 0; i < NVOICE; i++) {
            const voice_t *v = &t->v[i];
            uint32_t c;
            if (!v->active || v->stage == 4u || 0)
                continue;
            if (!v->gate)
                c = 1;                                  /* released */
            else if (0 || (mode != V_POLY && i > 0))
                c = 2;                                  /* extra UNISON, or a voice left by a mode / cap change */
            else if (!soft && mode == V_POLY && i != low)
                c = 3;                                  /* held, not the bass */
            else
                continue;
            if (c < cat || (c == cat && v->age < (*pp)->v[best].age)) {
                cat = c;
                best = i;
                *pp = t;
            }
        }
    }
    return best;
}

/* (0.8.9) console status: voices_given_up counts events, one per voice faded out early, whatever asked (a voice
 * already fading is not counted again); voice_trims the share of them the load budget took: a released tail already
 * under -50 dB (inaudible, one per note while LOAD is tight); the overload guard's are audio.c shed_count; the rest
 * were taken for a new note with the budget of voices full (voices_stolen) */
static uint32_t voice_kills, voice_trims;               /* voices given up (budget, overload): console, hostsim */
static void voice_kill(voice_t *v)                      /* fade out over ~6 ms (env_tick stage 4; 0.6.74, was a block) */
{
    v->gate = 0;
    if (v->stage != 4u) {
        v->kfade = 0;                                   /* (0.6.74: the fade from its start) */
        voice_kills++;
    }
    v->stage = 4;
}

/* (0.6.18) the load budget takes only a tail that is nearly gone: the oldest released voice under -50 dB (any part; 0.6.19, was -30).
 * NVOICE = none: the new voice is added and the tails ring out (0.6.16-17 took the oldest released one, loud or not:
 * with a sequence running every note cut the tails; the overload guard at 80 % stays the last line) */
static uint32_t quiet_tail(track_t **pp)
{
    uint32_t p, i, best = NVOICE;
    for (p = 0; p < NPART; p++)
        for (i = 0; i < NVOICE; i++) {
            const voice_t *v = &trk[p].v[i];
            if (!v->active || v->gate || v->stage == 4u || v->env_out >= 104 || 0)
                continue;
            if (best == NVOICE || v->age < (*pp)->v[best].age) {
                best = i;
                *pp = &trk[p];
            }
        }
    return best;
}

/* the budget is full: free a voice for part t. 0 = nothing to take (soft) */
static int voice_room(track_t *t, int soft)
{
    track_t *vp = 0;
    uint32_t k;
    if (voices_busy() < voice_cap()) {
        if (load_tight && (k = quiet_tail(&vp)) < NVOICE) {
            voice_kill(&vp->v[k]);                      /* (the load budget: a dying tail makes the room) */
            voice_trims++;
        }
        return 1;
    }
    k = voice_victim(t, soft, &vp);
    if (k == NVOICE)
        return !soft;                                   /* hard: over the budget (cannot happen: each of the
                                                         * NPART < NVOICE parts protects one voice at most) */
    voice_kill(&vp->v[k]);
    return 1;
}

static voice_t *voice_reuse(track_t *t, voice_t *v)
{
    if (v->stage == 4u)
        voice_room(t, 0);                               /* its budget was taken before this block */
    return v;
}

/* POLY allocation (within the engine's voice cap). DRUM: reuse its lane; other engines: the same note.
 * Else a free voice: ROTATE takes
 * the next one round-robin (release tails ring out), REUSE (or any GLIDE) takes
 * the free voice whose last pitch is closest, so poly portamento moves each
 * voice the shortest way. Steal: the oldest released voice, else the oldest
 * held one, never the lowest held note (the bass). A free voice needs room in the
 * shared budget: when the voice to give up is one of this part's, it is restarted
 * in place instead. */
static voice_t *voice_alloc(track_t *t, uint32_t note)
{
    uint32_t i, np = trk_nvoice(t), best = np, low = np, nfree = 0;
    int32_t bd = 0x7FFFFFFF;

    for (i = 0; i < np; i++) {
        if (t->v[i].active && t->v[i].note == note)
            return voice_reuse(t, &t->v[i]);
        nfree += !t->v[i].active;
    }
    if (nfree && (voices_busy() >= voice_cap() || load_tight)) {   /* (0.6.16: the load budget too; 0.6.18: a dying tail) */
        track_t *vp = 0;
        uint32_t full = voices_busy() >= voice_cap(), k = full ? voice_victim(t, 0, &vp) : quiet_tail(&vp);
        if (k < np && vp == t)
            return &t->v[k];                            /* our own: restart it in place (no click) */
        if (k < NVOICE) {
            voice_kill(&vp->v[k]);
            voice_trims += !full;                       /* (the load budget's quiet tail, not a steal) */
        }
    }
    if (t->p[P_ALLOC] || t->p[P_GLIDE]) {
        for (i = 0; i < np; i++) {
            int32_t d = t->v[i].pitch_cur - (int32_t)note * 16;
            if (t->v[i].active)
                continue;
            d = d < 0 ? -d : d;
            if (!t->v[i].pitch_cur)
                d = 0x7FFFFFF0;                          /* never played: last choice */
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
    } else {
        for (i = 0; i < np && best == np; i++) {
            uint32_t k = (t->rr + i) % np;
            if (!t->v[k].active)
                best = k;
        }
        t->rr = (uint8_t)((best == np ? t->rr : best) + 1u) % np;
    }
    if (best < np)
        return &t->v[best];
    for (i = 0; i < np; i++)                             /* the lowest held note is protected */
        if (t->v[i].gate && (low == np || t->v[i].note < t->v[low].note))
            low = i;
    for (i = 0; i < np; i++)                             /* oldest released (not one fading out for another part) */
        if (!t->v[i].gate && t->v[i].stage != 4u && (best == np || t->v[i].age < t->v[best].age))
            best = i;
    if (best == np)
        for (i = 0; i < np; i++)                         /* oldest held, not the bass */
            if (i != low && (best == np || t->v[i].age < t->v[best].age))
                best = i;
    return voice_reuse(t, &t->v[best == np ? 0 : best]);
}

/* (VOICE) a glide sets out from where the voice sounds: the S-curve (eng_formant.c glide_sung) folded into pitch_cur (a
 * new note mid-glide: no jump) */
static void glide_from(voice_t *v)
{
    v->pitch_cur = (glide_sung(v) + 128) >> 8;
    v->gfrom = (int16_t)v->pitch_cur;
}
static __attribute__((noinline)) void glide_from_trk(const track_t *t, voice_t *v)   /* (a legato note, a chord glide) */
{
    ;
}

/* glide: RATE = a fixed speed, TIME = the same time for any interval. (0.9.8) glide 2: VOICE singing words, a legato
 * note with GLIDE 0: a singer's ~60 ms */
static void glide_set(track_t *t, voice_t *v, int glide)
{
    if (!glide || !v->pitch_cur) {
        v->pitch_cur = v->pitch16;
        v->gstep = 0;
        return;
    }
    if (t->p[P_GLMODE] || glide == 2) {
        int32_t d = v->pitch16 - v->pitch_cur, ticks = glide == 2 ? 80 : 1 + t->p[P_GLIDE] * t->p[P_GLIDE] / 8;
        d = d < 0 ? -d : d;
        v->gstep = d * 256 / ticks > 0 ? d * 256 / ticks : 1;
    } else {
        v->gstep = 0;
    }
}

/* (JIANT 0.6.81) SCL TRANS: the track's every note this many semitones up or down as it sounds (the keys, the
 * sequence, MIDI, the ARP alike; recorded as played: it was the keys' alone, the sequence did not follow). Kits: none */
static int32_t trk_trans(const track_t *t)
{
    const engine_t *e = ENGINES[t->engine % NENGINES];
    return e->oneshot || e->keys ? 0 : t->p[P_TRANS];
}
static void voice_start(track_t *t, voice_t *v, uint32_t note, uint32_t vel, int glide)
{
    const engine_t *e = ENGINES[t->engine];
    int sounding = v->active && v->stage != 0;
    uint32_t ph0 = v->ph[0], ph1 = v->ph[1], ph2 = v->ph[2];
    int32_t s0 = v->s[0], s1 = v->s[1], s4 = v->s[4], s5 = v->s[5], s6 = v->s[6], s7 = v->s[7];
    uint32_t keep = e->keep;
    v->note = (uint8_t)note;
    v->vel = (uint8_t)vel;
    v->gate = 1;
    v->active = 1;
    v->stage = 1;
    v->kfade = 0;
    v->age = ++vage;
    ;
    v->fin_d = 0;
    v->gacc = 0;
    v->pitch16 = ((int32_t)note + trk_trans(t)) * 16 + t->pfx_rpit;   /* (pfx.c RANDOM: 0 but while it is held) */
    v->mvel = t->m_vel;                                 /* mod.c: the note's VEL and RAND */
    v->mrnd = t->m_rnd;
    v->henv = t->hum_env;                               /* (0.6.92) HUMAN: this note's DEC / REL moved */
    t->m_vi = (uint8_t)(v - t->v);
    glide_set(t, v, glide);
    if (!sounding) {
        v->env = 0;
        v->env_out = 0;
    }                                                   /* sounding: the attack starts from the current level */
    e->note_on(t, v);
    if (sounding && !e->sampled && t->engine < ENGI_M2STAT) {                     /* retrigger / steal: keep phases and filter */
        v->ph[0] = ph0;                                 /* states (resetting them clicks) */
        v->ph[1] = ph1;
        v->ph[2] = ph2;
        if (keep & 0x01u)                               /* engine_t.keep: the slots the engines use */
            v->s[0] = s0;
        if (keep & 0x02u)
            v->s[1] = s1;
        if (keep & 0x10u)
            v->s[4] = s4;
        if (keep & 0x20u)
            v->s[5] = s5;
        if (keep & 0x40u)
            v->s[6] = s6;
        if (keep & 0x80u)
            v->s[7] = s7;
        if (e == &ENG_LOFI && t->p[P_LRTRG] && t->p[P_E1] >= RW_BYTE)   /* (0.6.12) RTRG: BYTE's / FLOAT's time from 0 */
            v->ph[0] = v->ph[1] = 0;
    }
}

/* MONO / LEGATO / UNISON: one note on one voice (eight for UNISON, or the
 * engine's voice cap, spread by DETUNE over the same width) */
static void mono_play(track_t *t, uint32_t note, uint32_t vel, int retrig, int glide)
{
    uint32_t mode = (uint32_t)t->p[P_VOICE], nv = mode == V_UNISON ? trk_nvoice(t) : 1u, i;
    for (i = 0; i < nv; i++) {
        voice_t *v = &t->v[i];
        int32_t k = 2 * (int32_t)i - (int32_t)(nv - 1u);   /* -7 .. 7 */
        if (nv > 1u && nv < NVOICE)
            k = k * (NVOICE - 1) / (int32_t)(nv - 1u);      /* fewer voices: the outer ones as wide */
        v->fine = nv > 1u ? k * t->p[P_DETUNE] * 56 / 889 : 0;   /* up to ~±40 cents */
        if (retrig || !v->active || !v->gate) {
            if ((!v->active || v->stage == 4u) && !voice_room(t, i > 0))
                continue;                                   /* no room for this extra UNISON voice */
            /* level: about the same sum for 8 or 4 voices at random phases */
            voice_start(t, v, note, nv >= NVOICE ? vel * 36u / 100u : nv > 1u ? vel / 2u : vel, glide);
            if (nv > 1u && i && !ENGINES[t->engine]->sampled) {   /* random start phases: */
                static uint32_t seed = 0x1234567u;          /* in phase they stack, evenly spread they cancel */
                seed = seed * 1664525u + 1013904223u;
                v->ph[0] += seed;
            }
        } else {                                            /* legato: new pitch, same envelope */
            v->note = (uint8_t)note;
            glide_from_trk(t, v);
            v->pitch16 = ((int32_t)note + trk_trans(t)) * 16 + t->pfx_rpit;
            if(t->engine==ENGI_ACID){v->vel=(uint8_t)vel;acid_on(t,v);}
            v->mvel = t->m_vel;
            v->mrnd = t->m_rnd;
            if (vel > v->vel && nv == 1u)
                v->vel = (uint8_t)vel;
            /* (0.9.8) VOICE singing words: a legato note glides a little even with GLIDE 0 (a singer's ~60 ms) */
            glide_set(t, v, glide ? glide : 0);
        }
    }
    t->mono_note = (uint8_t)note;
}

/* the note the mono stack asks for (PRIO: LAST / LOW / HIGH), 0 = none */
static uint32_t mono_pick(const track_t *t)
{
    uint32_t i, n;
    if (!t->nmono)
        return 0;
    n = t->mono_stack[t->nmono - 1u];
    for (i = 0; i < t->nmono; i++) {
        if (t->p[P_PRIO] == 1 && t->mono_stack[i] < n)
            n = t->mono_stack[i];
        if (t->p[P_PRIO] == 2 && t->mono_stack[i] > n)
            n = t->mono_stack[i];
    }
    return n;
}

static void mono_remove(track_t *t, uint32_t note)
{
    uint32_t j, k = 0;
    for (j = 0; j < t->nmono; j++)
        if (t->mono_stack[j] != note)
            t->mono_stack[k++] = t->mono_stack[j];
    t->nmono = (uint8_t)k;
}

static int pfx_note(track_t *t, uint32_t note, uint32_t vel);   /* pfx.c (in fx.c) */
static uint8_t trk_hush;
static uint8_t trk_live = 4u;
static volatile uint8_t six_machine_mask=3u;
static int six_track_enabled(unsigned k){return k<trk_live&&k<NTRK;}
/* GEN ALL follows active slots and preserves explicitly assigned special
 * machines wherever they live. Empty slots are eligible for a new instrument. */
static uint8_t six_gen_work_mask; /* Eligible slots captured for one synchronous GEN transaction. */
static unsigned six_gen_next(unsigned k){
 if(six_gen_work_mask){while(k<4u&&!((six_gen_work_mask>>k)&1u))k++;return k<4u&&k<trk_live?k:NTRK;}
 while(k<4u&&(trk[k].eng_req==ENGI_ACID||trk[k].eng_req==ENGI_BREAK||trk[k].eng_req==ENGI_HORT||trk[k].eng_req==ENGI_LXR||trk[k].eng_req==ENGI_KW_KICK))k++;
 return k<4u&&k<trk_live?k:NTRK;
}
/* Inactive slots reject notes without generating a global editor popup. */
static void trk_note_on(track_t *t, uint32_t note, uint32_t vel)
{
    uint32_t any = 0, i, mode = trk_vmode(t);
    if (t->eng_req == ENGI_EMPTY) return; /* Unassigned tracks never allocate voices. */
    if (!six_track_enabled((unsigned)(t-trk))) {
        return;
    }
    if (t->p[P_MUTE] || ((trk_hush >> ((uint32_t)(t - trk) % NTRK)) & 1u) ||
        0)   /* (DRUM: its group mutes) */
        return;
    if (pfx_note(t, note, vel))                         /* the punch-in effects (pfx.c): a repeat holds the track */
        return;
    if (t->xf_on || t->eng_req != t->engine) {          /* engine switch under way: after the fade */
        for (i = 0; i < t->xp_n && t->xp_note[i] != note; i++)
            ;
        if (i == t->xp_n && t->xp_n < 4u)
            t->xp_n++;
        i = i < t->xp_n ? i : t->xp_n - 1u;             /* (full: the last one is replaced) */
        t->xp_note[i] = (uint8_t)note;
        t->xp_vel[i] = (uint8_t)vel;
        return;
    }
    six_vis_note_vel[t-trk]=(uint8_t)clamp((int)vel,1,127);
    six_vis_note_at[t-trk]=fm1_ms+1u;
    if(t->engine==ENGI_BREAK){six_break_note(t,note,vel);return;}
    mod_note(t, note, vel);                             /* the matrix's VEL / KEY / RAND */
    for (i = 0; i < NVOICE; i++)
        any |= t->v[i].gate;
    if (!any && t->p[P_LPHASE] >= 0) {                 /* fresh phrase, MODE TRIG: the LFO from PHASE, FADE from 0.
                                                         * (0.9.18) FREE (PHASE -1) restarts neither: it runs on, its
                                                         * FADE once from a project's load (lfo_fade_restart) */
        t->lfo_ph = (uint32_t)t->p[P_LPHASE] << 25;
        t->lfo_fade = 0;
    }
    if(!any&&t->p[P_L2PHASE]>=0){t->lfo2_ph=(uint32_t)t->p[P_L2PHASE]<<25;t->lfo2_fade=0;}
    if (mode == V_POLY) {
        voice_t *v = voice_alloc(t, note);
        t->nmono = 0;                                   /* no stale mono stack after a mode change */
        t->mono_note = 0;
        v->fine = 0;
        voice_start(t, v, note, vel, t->p[P_GLIDE] != 0 && !ENGINES[t->engine]->oneshot);
        return;
    }
    {
        uint32_t sounding = t->mono_note && t->v[0].active && t->v[0].gate, want;
        mono_remove(t, note);
        if (t->nmono >= 8u)
            mono_remove(t, t->mono_stack[0]);
        t->mono_stack[t->nmono++] = (uint8_t)note;
        want = mono_pick(t);
        if (sounding && want == t->mono_note)
            return;                                     /* LOW / HIGH priority: this key does not win */
        if (mode == V_MONO)                             /* MONO: always retrigger, glide when GLIDE is set */
            mono_play(t, want, vel, 1, t->p[P_GLIDE] != 0 || t->slide_glide);
        else                                            /* LEGATO / UNISON: glide only between held notes */
            mono_play(t, want, vel, !sounding, sounding && (t->p[P_GLIDE] != 0 || t->slide_glide));
    }
}

static void trk_note_off(track_t *t, uint32_t note)
{
    if(t->engine==ENGI_BREAK){six_break_note_off(t,note);return;}
    uint32_t i, k = 0, mode = trk_vmode(t);
    for (i = 0; i < t->xp_n; i++)                       /* not sounding yet (engine switch): forget it */
        if (t->xp_note[i] != note) {
            t->xp_note[k] = t->xp_note[i];
            t->xp_vel[k++] = t->xp_vel[i];
        }
    t->xp_n = (uint8_t)k;
    mono_remove(t, note);                              /* a mode change must not retain a released key */
    if (mode != V_POLY) {
        uint32_t nv = mode == V_UNISON ? trk_nvoice(t) : 1u;
        if (t->mono_note == note) {
            uint32_t next = mono_pick(t);
            if (next) {                                 /* fall back to a held note, legato */
                mono_play(t, next, t->v[0].vel, 0, t->p[P_GLIDE] != 0);
            } else {
                for (i = 0; i < nv; i++)
                    if (t->v[i].gate) {
                        t->v[i].gate = 0;
                        t->v[i].stage = 3;
                    }
                t->mono_note = 0;
            }
        }
    }
    for (i = 0; i < NVOICE; i++)                        /* a fallback above already has its new pitch */
        if (t->v[i].note == note && t->v[i].gate) {
            t->v[i].gate = 0;
            t->v[i].stage = 3;
        }
}

static void trk_all_off(track_t *t)
{
    if(t->engine==ENGI_BREAK){t->v[0].s[BENV_SEQ]=t->v[0].s[BENV_KEYS]=0;six_break_env_release(t);t->v[0].s[BENV_OFF]=33;t->nmono=t->xp_n=0;return;}
    uint32_t i;
    for (i = 0; i < NVOICE; i++) {
        t->v[i].gate = 0;
        t->v[i].stage = t->v[i].active ? 3 : 0;
    }
    t->nmono = 0;
    t->mono_note = 0;
    t->xp_n = 0;
}

/* engine switch, at each block start (events_block), before any note of the block. The UI writes
 * eng_req and the new engine's P_E0..P_E7 together (IRQ off). The part's sounding voices (released by
 * the preset change) then fade out over XF_BLOCKS blocks on the old engine, rendered with its own
 * parameters (pe_old: an engine never reads another engine's values, which index its tables); only
 * then the engine switches and the notes that came during the fade start on it. A part with nothing
 * sounding switches at once. */
#define XF_BLOCKS 4u                                    /* 4 x 32 samples: 2.9 ms */
/* (0.6.41) smoother: an engine switch fades out over XF_ENG (11.6 ms) and what was held (keys, the sequencer's notes:
 * xf_held, before the load's release) starts on the new engine, fading in over XF_ENG; an engine's list value
 * (WAVE, CHIP, TYPE .. F_ENUM) changed while it sounds: a dip, XF_DIP out on the old value and in on the new one, the
 * voices going on (it clicked: the wave swapped mid-cycle); (0.6.81) a value with names too (FM6's ALG, its SLOT) */
#define XF_ENG 16u
#define XF_DIP 4u                                       /* (0.6.81: 2.7 ms each way, was 1.3: a tick) */
static int eng_kit(uint32_t e) { return ENGINES[e % NENGINES]->oneshot; }
static uint32_t xf_held(const track_t *t, uint8_t *nt, uint8_t *vl)   /* the notes held (up to 4): their count */
{
    uint32_t i, k, n = 0;
    if (eng_kit(t->engine) || eng_kit(t->eng_req))
        return 0;                                       /* (hits: nothing held) */
    for (i = 0; i < NVOICE; i++) {
        const voice_t *v = &t->v[i];
        if (!v->active || !v->gate)
            continue;
        for (k = 0; k < n && nt[k] != v->note; k++)
            ;
        if (k == n && n < 4u) { nt[n] = v->note; vl[n++] = v->vel; }
    }
    return n;
}
static void engine_block(track_t *t)
{
    uint32_t i, any = 0;
    if (!t->xf_on && t->eng_req == t->engine && !eng_kit(t->engine)) {   /* a list value changed while it sounds */
        const engine_t *e = ENGINES[t->engine % NENGINES];
        for (i = 0; i < 8u; i++) {                      /* (0.9.16) only a value that changed, then followed (pe_old:
                                                         * the last value heard): until 0.9.15 the engine's desc for all 8
                                                         * of every part, every block, stopped too (six engines' code a
                                                         * block: on the FM-1 most of PROFILE's SEQUENCER at rest) */
            const param_desc_t *d;
            uint32_t k;
            if (t->p[P_E0 + i] == t->pe_old[i])
                continue;
            d = e->desc ? e->desc(t, i) : 0;
            d = d ? d : &e->edit[i];
            /* (0.9.17) a value with names: only a new name dips; VOICE's THEME and LOOP never (the words, not the
             * sound: a THEME swept dipped at every one of its values, a held note crackling) */
            if (d->fmt == F_ENUM || (d->names && !(d >= FMT_WDESC && d < FMT_WDESC + 8) &&
                                     name_of(d, t->p[P_E0 + i], &k) != name_of(d, t->pe_old[i], &k)))
                break;
            t->pe_old[i] = t->p[P_E0 + i];
        }
        for (any = 0; i < 8u && any < NVOICE; any++)
            if (t->v[any].active && t->v[any].env_out)
                break;
        if (i < 8u && any < NVOICE) {
            t->xf_on = 1; t->xf = t->xf_len = XF_DIP; t->xf_dip = 1;
            return;                                     /* (pe_old: the old value, for the dip's way out) */
        }
        any = 0;
    }
    if (t->xf_on || t->eng_req != t->engine) {
        if (!t->xf_on) {
            for (i = 0; i < NVOICE; i++)
                any |= t->v[i].active;
            if (any) {
                t->xf_on = 1;
                t->xf = t->xf_len = XF_ENG;
                t->xf_dip = 0;
                return;
            }
        } else if (t->xf) {
            return;                                     /* still fading (track_render counts down) */
        }
        if (t->xf_dip) {                                /* the dip's end: the same voices, in again on the new value */
            t->xf_on = t->xf_dip = 0;
            t->xin = t->xin_len = XF_DIP;
            for (i = 0; i < 8u; i++)
                t->pe_old[i] = t->p[P_E0 + i];
            return;
        }
        for (i = 0; i < NVOICE; i++) {                  /* faded to 0: gone */
            voice_t *v = &t->v[i];
            v->active = v->gate = 0;
            v->stage = 0;
            v->env = v->env_out = 0;
        }
        any = t->engine != eng_idx(t->eng_req);
        if(any&&(t->engine==ENGI_BREAK||t->eng_req==ENGI_BREAK))memset(t->v[0].s,0,4*sizeof(t->v[0].s[0]));
        if(any&&(t->engine==ENGI_ACID||t->eng_req==ENGI_ACID)){
            acid_reset(t);
        }
        t->engine = eng_idx(t->eng_req);
        t->xf_on = 0;
        t->nmono = 0;
        t->mono_note = 0;
        {
            uint32_t n = t->xp_n;
            t->xp_n = 0;
            for (i = 0; i < n; i++)
                trk_note_on(t, t->xp_note[i], t->xp_vel[i]);
            if (n && any)                               /* (0.6.41) on the new engine: in, not at once */
                t->xin = t->xin_len = XF_ENG;
        }
    }
    for (i = 0; i < 8u; i++)                            /* the engine's own values, for a later fade */
        t->pe_old[i] = t->p[P_E0 + i];
}

/* (0.6.13) the sound a track had before a load (ui.c load_begin, the main loop, before it writes the new values): the
 * fade renders with all of it, not only its engine's values (pe_old): the filter, its envelope, the LFO .. as they were.
 * One at a time (a load is one track's; a section's six: the others fade on pe_old as before) */
static int16_t xf_snap[P_COUNT];
static volatile uint8_t xf_snap_t = 0xFFu;              /* its track, 0xFF none */
/* (0.6.13) a sound loaded (a preset, a user preset, a section: seq.c panic_req): what still sounds fades out over
 * XF_BLOCKS on the values it had (as an engine switch does), not its release on the new sound's (its filter, its
 * levels: the old notes jumped bright and loud, sharp highs at every preset change); the notes asked for meanwhile
 * after it */
static void trk_fade_out(track_t *t)
{
    uint32_t i, any = 0;
    if (t->xf_on)
        return;
    for (i = 0; i < NVOICE; i++)
        any |= t->v[i].active;
    if (any) {
        t->xf_on = 1;
        t->xf = t->xf_len = t->eng_req != t->engine ? XF_ENG : XF_BLOCKS;   /* (0.6.41: another engine, longer) */
        t->xf_dip = 0;
    } else if (xf_snap_t == (uint32_t)(t - trk)) {
        xf_snap_t = 0xFFu;                              /* (nothing to fade: no snapshot left for a later one) */
    }
}

/* one control tick (CTL samples) of the amplitude envelope; returns Q15 */
static int32_t env_tick(track_t *t, voice_t *v)
{
    ;
    const int16_t *p = t->p;
    int32_t sus = (int32_t)p[P_SUS] << 17;              /* Q24 */
    switch (v->stage) {
    case 1:
        v->env += (int32_t)ENV_LIN[p[P_ATK] & 127];
        if (v->env >= (1 << 24)) {
            v->env = 1 << 24;
            v->stage = 2;
        }
        break;
    case 2:
        v->env += mulq16(sus - v->env, ENV_EXP[clamp(p[P_DEC] + v->henv, 0, 127)]);
        if (p[P_ELOOP] > 0 && v->gate && v->env - sus < (1 << 18))   /* (JIANT 0.4) LOOP: at the sustain (within
                                                         * 1/64), held: the attack again from here (an ADSR-shaped LFO) */
            v->stage = 1;
        break;
    case 3:
        v->env -= mulq16(v->env, ENV_EXP[clamp(p[P_REL] + v->henv, 0, 127)]);
        if (v->env < (1 << 12)) {
            v->env = 0;
            v->stage = 0;
            v->active = 0;
        }
        break;
    case 4:                                             /* given up (another part, the load): it fades out. (JIANT
                                                         * 0.6.74) A half cosine over 6 blocks (~4.4 ms), each block's
                                                         * ramp between (KFADE: each block's gain over the last's):
                                                         * gentle in and out. One block (0.7 ms, full to 0, as before)
                                                         * clicked on every steal, a bass note most; longer would keep
                                                         * more voices rendering under load */
    {
        static const uint8_t KFADE[6] = {239, 206, 171, 128, 69, 0};
        v->env = (int32_t)(((int64_t)v->env * KFADE[v->kfade < 6u ? v->kfade : 5u]) >> 8);
        v->kfade++;
        if (v->kfade >= 6u || !v->env) {
            v->env = 0;
            v->stage = 0;
            v->active = 0;
        }
        break;
    }
    default:
        v->env = 0;
        break;
    }
    return v->env >> 9;
}

/* (JIANT 0.7.8) DRIFT: each voice its own slow value noise (mod.c drift_noise), on the track's blocks */
static uint32_t drift_clk[NTRK];

/* render one block of a part into out (cleared here); returns the voices rendered */
/* Channel bend is live performance state, outside projects/presets. Q8 semitones. */
static int32_t midi_bend_q8[NTRK], midi_bend_target[NTRK];
static uint32_t track_render(track_t *t, int32_t *out, uint32_t n)
{
    if(t->engine==ENGI_BREAK){
        voice_t *v=&t->v[0];vmod_t m={0};if(n>CTL)n=CTL;if(!n)return 0;
        track_lfo_tick(t);six_lfo2_tick(t);
        int32_t lfo=mulq15(t->lfo_val,t->lfo_fade),env=env_tick(t,v);
        t->m_env=env;m.envq15=env;m.amp0=v->env_out;m.amp1=mulq15(env,v->vel*258);
        m.pitch16=clamp(60*16+((lfo*t->p[P_LD_PIT]*3)>>15)+((env*t->p[P_ED_PIT]*3)>>15),0,2047);
        if(t->p[P_LD_AMP])m.amp1=mulq15(m.amp1,32767-mulq15((lfo+32768)>>1,t->p[P_LD_AMP]*258));
        if(MOD.on)mod_voice(t,v,&m,0);
        v->s[BENV_CUT]=m.cutoff;v->env_out=m.amp1;
        if(!env&&v->s[BENV_OFF]){jungle_sequence_off((unsigned)v->s[BENV_OFF]-1u);v->s[BENV_OFF]=0;}
        jungle_pitch((m.pitch16-60*16)/16);
        jungle_feedback((unsigned)t->p[P_E0]);jungle_variation((unsigned)t->p[P_E1]);
        jungle_warp((unsigned)t->p[P_E2]);jungle_filter((unsigned)t->p[P_E3]);
        six_break_render(t,out,n);uint32_t nr=0;
        track_post(t,ENGINES[ENGI_BREAK],out,n);
        int32_t gain=m.amp0,delta=(m.amp1-m.amp0)/(int32_t)n;
        for(unsigned j=0;j<n;j++){gain+=delta;out[j]=mulq15(out[j],gain);nr|=out[j]!=0;}
        if(t->xf_on&&t->xf)t->xf--; /* control state is never an allocated synthesis voice */
        return nr;
    }
    const engine_t *e = ENGINES[t->engine];
    const int16_t *p = t->p;
    uint32_t i;
    int32_t lfo = mulq15(t->lfo_val, t->lfo_fade);
    /* TUNE in cents: whole 1/16 semitones in the pitch, the rest as a fine factor (no dead zone) */
    int32_t tune = song.g[G_TUNE] >= 0 ? song.g[G_TUNE] * 16 / 100 : -((-song.g[G_TUNE] * 16 + 99) / 100);
    int32_t tune_fine = (song.g[G_TUNE] * 16 - tune * 100) * 2367 / 16000;   /* rest, in 1/4096 (1 ct = 2.367) */
    int32_t bend, bend16, bend_fine;
    uint32_t ti = (uint32_t)(t - trk);
    {
        int32_t d = midi_bend_target[ti] - midi_bend_q8[ti];
        /* ~6 ms smoothing, with an exact landing (no permanent small offset). */
        midi_bend_q8[ti] += d > 0 ? (d < 4 ? d : (d + 3) / 4) : (d > -4 ? d : (d - 3) / 4);
    }
    bend = midi_bend_q8[ti];
    bend16 = bend >= 0 ? bend / 16 : -((-bend + 15) / 16);
    bend_fine = (bend - bend16 * 16) * 2367 / 2560;
    uint32_t nr = 0, fade = t->xf_on && t->xf, snap = fade && xf_snap_t == ti;
    int32_t damt;
    int16_t pe_new[8], p_new[P_COUNT];
    for (i = 0; i < n; i++)
        out[i] = 0;
    if (snap) {                                         /* (0.6.13) a sound load: the whole sound as it was */
        memcpy(p_new, t->p, sizeof p_new);
        memcpy(t->p, xf_snap, sizeof p_new);
    } else if (fade)                                    /* engine switch: the old engine, its own values */
        for (i = 0; i < 8u; i++) {
            pe_new[i] = t->p[P_E0 + i];
            t->p[P_E0 + i] = t->pe_old[i];
        }
    track_lfo_tick(t);six_lfo2_tick(t);
    {   /* (0.6.50) MORPH slewed (at most 3 of the knob's steps a block) and ramped by the engines across the block */
        int32_t g = clamp(p[P_MORPH], 0, 127) << 8, c = t->mo_cur;
        t->mo_prev = (uint16_t)c;
        t->mo_cur = (uint16_t)(c + clamp(g - c, -(3 << 8), 3 << 8));
    }

    if (e->block)                                       /* the engine's per-part work (WHEEL: bars, rotor) */
        e->block(t);
    damt = 127 - clamp(p[P_DRIFT], 0, 127);   /* (0.7.8) DRIFT, 127 stored = 0 % */
    if (damt)
        drift_clk[ti]++;
    for (i = 0; i < NVOICE; i++) {
        voice_t *v = &t->v[i];
        vmod_t m;
        int32_t env, pitch, dfine, dcut, fsum;
        if (!v->active)
            continue;
        {
            env = env_tick(t, v);
            if (e->ownenv && v->active) {               /* the engine's envelopes (FM6): they end the voice */
                if (e->done(t, v)) {
                    v->active = v->gate = 0;
                    v->stage = 0;
                    v->env = v->env_out = 0;
                    continue;
                }
                if (v->stage != 4u) {                   /* (0.6.74: given up, env_tick's fade) */
                    v->env = 1 << 24;                   /* (the ADSR's release never ends it) */
                    env = 32767;
                }
            }
            if (e->amp)                                 /* the engine's own amplitude curve */
                env = e->amp(t, v, env);
            m.envq15 = e->ownenv ? 0 : env;
            m.amp1 = e->ownenv ? env : mulq15(env, v->vel * 258);
            if (p[P_LD_AMP])
                m.amp1 = mulq15(m.amp1, 32767 - mulq15((lfo + 32768) >> 1, p[P_LD_AMP] * 258));
            if (fade)                                   /* linear to 0 over the fade */
                m.amp1 = m.amp1 * (int32_t)(t->xf - 1u) / (int32_t)(t->xf_len ? t->xf_len : XF_BLOCKS);
            else if (t->xin)                            /* (0.6.41) in, linear, after a switch or a dip */
                m.amp1 = m.amp1 * (int32_t)(t->xin_len - t->xin + 1u) / (int32_t)(t->xin_len + 1u);
            if (v->fin_d) {                             /* (0.6.81) a chord glide's new note, in as it glides */
                int32_t r = v->pitch16 - v->pitch_cur;
                r = r < 0 ? -r : r;
                if (r >= (int32_t)v->fin_d) r = v->fin_d - 1;
                m.amp1 = m.amp1 * ((int32_t)v->fin_d - r) / (int32_t)v->fin_d;
                if (!r) v->fin_d = 0;
            }
            m.amp0 = v->env_out;
            v->env_out = m.amp1;
        }
        if (v->pitch_cur != v->pitch16) {               /* glide */
            int32_t d = v->pitch16 - v->pitch_cur;
            int32_t st;
            if (v->gstep) {                             /* TIME: Q8, the fraction carried (0.6.82) */
                int32_t q = v->gacc + v->gstep;
                st = q >> 8;
                v->gacc = (uint8_t)(q & 255);
            } else {
                st = (int32_t)(ENV_LIN[(p[P_GLIDE] ? p[P_GLIDE] : 40) & 127] >> 14);   /* slide: ~45 ms */
                if (st < 1)
                    st = 1;
            }
            v->pitch_cur += d > 0 ? (d < st ? d : st) : (-d < st ? d : -st);
        }
        if (!env && !m.amp0 && v->stage == 2 && !e->sampled)
            continue;                                   /* held at a silent sustain (SUS 0): nothing to render */
        pitch = v->pitch_cur + t->pfx_pit + tune + bend16 + ((lfo * p[P_LD_PIT] * 3) >> 15) + ((m.envq15 * p[P_ED_PIT] * 3) >> 15);
        m.pitch16 = clamp(pitch, 0, 2047);
        m.inc = pitch_inc(m.pitch16);
        dfine = dcut = 0;
        if (damt) {                                     /* (0.7.8) DRIFT: up to ~27 ct, and the filter a little */
            dfine = (drift_noise(ti * 8u + i * 1013u, drift_clk[ti] + i * 397u, 10u) * damt) >> 16;   /* (~0.74 s) */
            dcut = (drift_noise(ti * 8u + i * 1013u + 0x5bd1u, drift_clk[ti] + i * 211u, 11u) * damt) >> 12;   /* (~1.5 s) */
        }
        fsum = v->fine + tune_fine + bend_fine + dfine;
        m.fine = fsum;
        if (fsum)                                       /* residual below 1/16 semitone */
            m.inc += (uint32_t)((int32_t)(m.inc >> 12) * fsum);
        m.cutoff = ((lfo * p[P_LD_FLT]) >> 7) + ((m.envq15 * p[P_ED_FLT]) >> 7) + dcut;
        if (v->vel > 110)                               /* accent opens the filter with the env */
            m.cutoff += (m.envq15 * 24) >> 7;
        m.shape = (64 << 8) + ((lfo * p[P_LD_SHP]) >> 7) + ((m.envq15 * p[P_ED_SHP]) >> 7);
        if (MOD.on)                                     /* the modulation matrix (mod.c) */
            mod_voice(t, v, &m, fsum);
        e->render(t, v, out, n, &m);
        nr++;
    }
    ;
    if (nr && (t->p[P_FTYPE] || t->p[P_FCUT] < 127 || t->p[P_FRES] || tf_on[(uint32_t)(t - trk) % NTRK] ||
               ((e == &ENG_WHEEL || 0) && (t->p[P_LD_FLT] || t->p[P_ED_FLT] || lfo2_dest_value(t,1))) ||   /* (0.6.81: their
                                                         * only filter, for the LFO / ENV -> FILTER) */
               tf_xb[(uint32_t)(t - trk) % NTRK] || tf_cmb[(uint32_t)(t - trk) % NTRK]))
        /* (JIANT 0.5) the FILTER (track_post); 0.6.8: and a block more to leave the chain (track_filter's fade) */
        track_post(t, e, out, n);
    if (snap)
        memcpy(t->p, p_new, sizeof p_new);
    else if (fade)
        for (i = 0; i < 8u; i++)
            t->p[P_E0 + i] = pe_new[i];
    if (!fade && t->xin)
        t->xin--;                                       /* (0.6.41) the fade-in's next block */
    if (fade && !--t->xf && snap)
        xf_snap_t = 0xFFu;                              /* (faded out: the snapshot done with) */
    return nr;
}
