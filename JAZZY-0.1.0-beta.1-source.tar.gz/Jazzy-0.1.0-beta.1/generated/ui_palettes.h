/* generated JAZZY semantic palettes */
#pragma once
static const ui_pal_t UI_PALETTES[] = {
    {"DARK",0x0000,0x0000,0xef7b,0x75b9,0xfbab},
    {"LIGHT",0xef5b,0xef5b,0x1945,0x132e,0x99a3},
};
static const uint8_t UI_STORAGE_IDS[2]={73,75};
static const uint8_t UI_RAISE_OF[2]={12,12};
static const uint16_t UI_KNOBS[2][4]={{0x75b9,0xddad,0xc698,0xfbab},{0x132e,0x7283,0x32a9,0x99a3}};
#define UI_NPALETTES 2u
#define UI_BW_INDEX 0u
#define UI_INVERT_INDEX 1u
#define UI_BW_GREY 0x528au
#define UI_PAL_TAG 64u
#define UI_MID_PCT 76
#define UI_DIM_PCT 60
#define UI_LINE_PCT 25
#define UI_SEL_PCT 80
#define UI_TINT_PCT 12
#define UI_KEY_PCT 78
#define UI_RAISE_PCT 12
#define UI_REC_DARK 0xfa86u
#define UI_REC_LIGHT 0xb9c3u
#define UI_QR_LIGHT 0xffffu
#define UI_QR_DARK 0u
#define UI_CRASH_BG 0u
#define UI_CRASH_INK 0xffffu
